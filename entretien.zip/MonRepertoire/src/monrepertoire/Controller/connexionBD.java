
package monrepertoire.Controller;
import  java.sql.*;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;

/**
 *
 * @author osbybb young
 */
public class connexionBD {
    static Connection conn;
    static Statement st;
    static ResultSet rst;
    
    public static void main(String[] args) {
        // on fait un petit test pour voir si tout ce passe bien dans la base de donner
        // donc cette methode n'est rien d'autre qu'une methode de test
        System.out.println("entrez dans fonction main");
       
          try {
              
            conn = connexion();
            st =conn.createStatement();
            rst= st.executeQuery(" SELECT * FROM eleve");
              while (rst.next()) {
                  System.out.print(rst.getInt("id")+"\t");
                  System.out.print(rst.getString("matricule")+"\t");
                  System.out.print(rst.getString("nom")+"\t");
                  System.out.print(rst.getString("prenoms")+"\t");
                  System.out.print(rst.getString("sexe")+"\t");
                  System.out.print(rst.getString("classe")+"\t");
                  System.out.print(rst.getInt("anneescol")+"\t");
                  System.out.print(rst.getString("photo")+"\t");
                  System.out.println(rst.getString("eleve"));
              }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
        // la methode connection sere a etablir la connection a la base de donne
    public static Connection connexion(){
        try {
            //ICI ON CHARGE LE PILOTE JDBC POUR MYSQL PUIS ON CREE LA CONNECTION
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/entretien","root","");
             if (conn != null)
                
                 System.out.println("LA CONNEXION A LA BASE DE DONNEES EST ETABLIE AVEC SUCCES !!!");
             else
                 System.out.println("PROBLEME DE CONNEXION A LA BASE DE DONNEES");
             return  conn;
        } catch (Exception e) {
            System.out.println("--> SQLException :" + e);
            return null;
        }
    
    
    }
    //la methode d'ajout de personne a la base de donnees
    public static void AjouterPs(String nom, String prenoms,String sexe,String prefession,int contact1, int contact2,String email1,String email2,String photo) {
        try {
            String Req_ajout = " INSERT INTO personnages VALUES("+nom+","+prenoms+","+sexe+","+prefession+","+contact1+","+contact2+","+email1+","+email2+","+photo+")";
           conn = connexion();
            st =conn.createStatement();
            st.executeUpdate(Req_ajout);
            System.out.println("le personnage a bien été ajouté avec succès");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
   
    }
    // la methode de suppression d'une personne dans la base 
    public static void SupprimerPs(int id) {
        try {
            String Req_supprimer ="DELETE FROM personnages WHERE id="+id;
            conn =connexion();
            st =conn.createStatement();
            st.executeUpdate(Req_supprimer);
            System.out.println("LA PERSONNE A BIEN ETE SUPPRIMEE  avec succès");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    //la methode de recherche d'un eleve
    public static void RechercherPs(String nom) {
         try {
            String Req_rechercher ="SELECT * FROM personnages WHERE nom='"+nom+"'";
            conn =connexion();
            st =conn.createStatement();
            rst =st.executeQuery(Req_rechercher);
            rst.last();
            int nombreColonne = rst.getRow();
             if (nombreColonne !=0) {
                 System.out.println("personnage trouvé dans la liste");
                 
             } else {
                 System.out.println("personnage  non trouvé dans la liste");
             }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
    }
 //modifier les coordonnees d'un eleve
    public static void ModifierPs(String N_nom, String N_prenoms,String N_sexe,String N_classe,String N_matricule, String N_anneesco,String N_photo) {
        try {
             String Req_modifier ="UPDATE personnages SET nom='"+N_nom
                     +"'prenoms="+N_prenoms
                     +",sexe="+N_sexe
                     +",classe="+N_classe
                     +",matricule="+N_matricule
                     +",anneesco="+N_anneesco
                     +"'photo="+N_photo
                     +"WHERE matricule="+N_matricule;
            conn =connexion();
            st =conn.createStatement();
            st.executeUpdate(Req_modifier);
            System.out.println("les modifications ont été envoyé avec succès");
        } catch (SQLException e) {
             System.out.println(e.getMessage());
        }
        
    }
// ajouter un nouveau eleve
    public static void AjouterPs(JTextField TFmatri, JTextField TFnom, JTextField TFprenoms, JComboBox CBsexe, JComboBox CBclasse, JTextField TFannscol, JButton BTajouterPhoto) {
        throw new UnsupportedOperationException("Not supported yet."); 
//To change body of generated methods, choose Tools | Templates.
    }
    
}
